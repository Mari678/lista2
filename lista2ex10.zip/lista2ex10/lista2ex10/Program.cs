﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double media;

            Console.WriteLine("Digite o valor de P1: ");
            p1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor de P2: ");
            p2 = double.Parse(Console.ReadLine());

            media = (p1 + 2 * p2) / 3;

            Console.WriteLine("Com P1 valendo {0} e P2 valendo {1}, a média é {2}", p1, p2, media);

            if (media >= 5)
            {
                Console.WriteLine("Aprovado");
            }

            else
            {
                Console.WriteLine("Reprovado");
            }
        }
    }
}
