﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;

            Console.WriteLine("Digite o 1° valor: ");
            v1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2° valor: ");
            v2 = double.Parse(Console.ReadLine());

            if (v1 > v2)
            {
                Console.WriteLine("O primeiro valor é maior que o segundo.");
            }
            else
            {
                Console.WriteLine("O segundo valor é maior que o primeiro.");
            }
        }
    }
}
