﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;
            double h;
            double a;
            double b;

            Console.WriteLine("Digite o 1° valor: ");
            v1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2° valor: ");
            v2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 3° valor: ");
            v3 = double.Parse(Console.ReadLine());

            if (v1 > v2 && v1 > v3)
            {
                h = v1;
                a = v2;
                b = v3;
            }

            else
            {
                if (v2 > v1 && v2 > v3)
                {
                    h = v2;
                    a = v1;
                    b = v3;
                }
                else
                {
                    h = v3;
                    a = v1;
                    b = v2;
                }
            }

            if (h * h == (a * a) + (b * b))
            {
                Console.WriteLine("{0}, {1} e {2} formam um triângulo retângulo.", v1, v2, v3);
            }

            else
            {
                Console.WriteLine("{0}, {1} e {2} não formam um triângulo retângulo.", v1, v2, v3);
            }
        }
    }
}
