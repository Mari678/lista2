﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;
            double v3;

            Console.WriteLine("Digite o 1° valor: ");
            v1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2° valor: ");
            v2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 3° valor: ");
            v3 = double.Parse(Console.ReadLine());

            if (v1 == v2)
            {
                if (v1 == v3)
                {
                    Console.WriteLine("Os valores são iguais");
                }
                else
                {
                    if (v1 > v3)
                    {
                        Console.WriteLine("O 1º e 2º valores são maiores");
                    }
                    else
                    {
                        Console.WriteLine("O 3º valor é maior");
                    }
                }
            }

            else
            {
                if (v1 == v3)
                {
                    if (v1 > v2)
                    {
                        Console.WriteLine("O 1º e 3º valores são maiores");
                    }
                    else
                    {
                        Console.WriteLine("O 2º valor é maior");
                    }
                }

                else
                {
                    if (v2 == v3)
                    {
                        if (v2 > v1)
                        {
                            Console.WriteLine("O 2º e 3º valores são maiores");
                        }
                        else
                        {
                            Console.WriteLine("O 1º valor é maior");
                        }
                    }
                    else
                    {
                        if (v1 > v2)
                        {
                            if (v1 > v3)
                            {
                                Console.WriteLine("O 1º valor é maior");
                            }
                            else
                            {
                                Console.WriteLine("O 3º valor é maior");
                            }
                        }

                        else
                        {
                            if (v2 > v3)
                            {
                                Console.WriteLine("O 2º valor é maior");
                            }

                            else
                            {
                                Console.WriteLine("O 3º valor é maior");
                            }
                        }
                    }
                }
            }
        }
    }
}
