﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double base1;
            double altura;
            double area;

            Console.WriteLine("Digite o valor da base: ");
            base1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da altura: ");
            altura = double.Parse(Console.ReadLine());

            area = base1 * altura;

            Console.WriteLine("O terreno com base {0} e altura {1} possui {2} de área", base1, altura, area);

            if (area > 100)
            {
                Console.WriteLine("Terreno grande.");
            }
            else
            {
                Console.WriteLine("Terreno pequeno.");
            }
        }
    }
}
