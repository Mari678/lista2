﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double peso;
            double altura;
            double rpa;

            Console.WriteLine("Digite o peso: ");
            peso = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite a altura: ");
            altura = double.Parse(Console.ReadLine());

            rpa = peso / (altura * altura);

            if (rpa < 20)
            {
                Console.WriteLine("Abaixo do peso.");

            }
            else
            {
                if (rpa > 25)
                {
                    Console.WriteLine("Acima do peso.");
                }
                else
                {
                    Console.WriteLine("Peso normal.");
                }
            }
        }
    }
}
