﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double p1;
            double p2;
            double media = 5;

            Console.WriteLine("Digite o valor de P1: ");
            p1 = double.Parse(Console.ReadLine());

            p2 = (media * 3 - p1) / 2;

            Console.WriteLine("Com P1 valendo {0}, é necessario que P2 seja pelo menos {1} para que a média seja {2}", p1, p2, media);

        }
    }
}
