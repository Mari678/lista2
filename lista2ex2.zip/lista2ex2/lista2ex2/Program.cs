﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double v1;
            double v2;

            Console.WriteLine("Digite o 1° valor: ");
            v1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o 2° valor: ");
            v2 = double.Parse(Console.ReadLine());

            if (v1 == v2)
            {
                Console.WriteLine("Os valores são iguais.");
            }

            else
            {
                if (v1 > v2)
                {
                    Console.WriteLine("O maior valor é {0}", v1);
                }
                else
                {
                    Console.WriteLine("O maior valor é {0}", v2);
                }
            }

        }
    }
}
