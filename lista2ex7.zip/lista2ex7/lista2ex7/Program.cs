﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lista2ex7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double la;
            double lb;
            double lc;

            Console.WriteLine("Digite o valor do 1° lado: ");
            la = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do 2° lado: ");
            lb = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do 3° lado: ");
            lc = double.Parse(Console.ReadLine());

            if (la + lb > lc)
            {
                if (la + lc > lb)
                {
                    if (lb + lc > la)
                    {
                        if (la == lb)
                        {
                            if (la == lc)
                            {
                                Console.WriteLine("Triângulo equilátero.");
                            }
                            else
                            {
                                Console.WriteLine("Triângulo isósceles.");
                            }
                        }

                        else
                        {
                            if (la == lc)
                            {
                                Console.WriteLine("Triângulo isósceles.");
                            }
                            else
                            {
                                if (lb == lc)
                                {
                                    Console.WriteLine("Triângulo isósceles.");
                                }
                                else
                                {
                                    Console.WriteLine("Triângulo escaleno.");
                                }
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Não forma triângulo.");
                    }

                }
                else
                {
                    Console.WriteLine("Não forma triângulo.");
                }

            }

            else
            {
                Console.WriteLine("Não forma triângulo.");
            }

        }
    }
}
